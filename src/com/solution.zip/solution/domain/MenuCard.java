package com.solution.domain;

import java.util.List;

public interface MenuCard {

  List<Dish> availableDishes();
  List<Dish> disheshInMenu();
}
