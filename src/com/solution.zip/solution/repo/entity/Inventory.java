package com.solution.repo.entity;

import com.solution.domain.Ingredient;

public class Inventory {

  private final Ingredient ingredient;

  public Inventory(final Ingredient ingredient) {
    this.ingredient = ingredient;
  }
}
